#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void	print_subset(int *subset, int subset_size)
{
	if (size == 0)
	{
		printf("\n");
		return ;
	}
	int i = 0;
	while (i < subset_size)
	{
		if (i == subset_size - 1)
			printf("%d", subset[i]);
		else
			printf("%d ", subset[i]);
		i++;
	}
	printf("\n");
}

void	backtrack(int *set, int *subset, int set_size, int subset_size, int index, int sum, int *found)
{
	if (index == set_size)
	{
		print_subset(subset, subset_size);
		return 
	}

	backtrack();
}

int check_args(int ac, char **av)
{
	int i =0;
	while (i < ac)
	{
		int j = 0;
		if (av[i][j] == '+' || av[i][j] == '-')
			j++;
		while (av[i][j])
		{
			if (av[i][j] <= '0' || av[i][j] >= '9')
				return 0;
			j++;
		}
		i++;
	}
	return 1;
}

int main(int ac, char av)
{
	if (ac < 2)
	{
		printf("\n");
		return 1;
	}
	if (!check_args(ac, av))
		return 1;

	int i = 0;
	int set_size = ac - 2;

	if (set_size <= 0)
	{
		printf("\n");
		return 1;
	}

	int *subset;
	int *set;

	subset = malloc(set_size * sizeof(int));
	set = malloc(set_size * sizeof(int));
	if (!set || !subset)
	{
		free(set);
		free(subset);
		return 1;
	}

	int found = 0;

	backtrack (set, subset, set_size, 0, 0, 0, &found);

	if (!found)
	{
		printf("\n");
	}
	free(set);
	free(subset);
	return 0;
}

