#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

//the function is meant to print the subset
void	print_subset(int *subset, int size)
{
	//if there is nothing in the subset being passed, we will just print the new line 
	if (size == 0)
	{
		printf("\n");
		return ;
	}

	//if there is somehting in the subset, we will print it out
	int i = 0;
	//if it is the last number in the subset, there wouldn't be space after that number 
	while (i < size)
	{
		if (i == size - 1)
			printf("%d", subset[i]);
		else
			printf("%d ", subset[i]);
		i++;
	}

	//if the entire subset is printed, we will print the newline 
	printf("\n");
}

//functions to check if the numbers are only integers
int	check_args(int ac, char **av)
{
	int i = 1;//to skip ./.aout
	while ( i < ac)
	{
		int j = 0;
		//to skip the first '+' or '-'
		if (av[i][j] == '+' || av[i][j] == '-')
			j++;

		//to check if only the integer is in one argument 
		while (av[i][j])
		{
			if (av[i][j] < '0' || av[i][j] > '9')
				return 0; 
			j++;
		}
		i++;//skip to next argument 
	}
	return 1;
}

void	backtrack(int *set, int *subset, int set_size, int subset_size, int index, int current_sum, int target, int *found)
{
	//if we get to the end of the set, we will try to find if the current sum is what we are loon=king for, if so, we will print the current subset with the right numbers
	if (index == set_size)
	{
		if (current_sum == target)
		{
			print_subset(subset, subset_size);
			*found = 1;
		}
		//if we are at the end of set, we don't found the right subset
		//thus, we will return to the previous backtrack function 
		return; 
	}

	//decision 1. 
	//this is to leave it 
	//decision will make u go to the end of the set first and reverse it back 
	backtrack(set,subset, set_size, subset_size, index + 1, current_sum, target, found);
	
	//decision2. 
	//this is to take the number into subset 
	subset[subset_size]= set[index];
	backtrack(set, subset, set_size, subset_size + 1, index + 1, current_sum + set[index], target, found);

}
int	main(int ac, char **av)
{
	//we will check the user input first
	//if the user passed only one argument or the second argument passed is null or the second argument is passed withe null terminator (basically string)
	if (ac < 2)
	{
		printf("\n");
		return 0;
	}

	//now, we will check if the arguments being passed are of the right type (integers)
	if (!check_args(ac, av))
		return 1;

	//now, we will take the first int being passed as the target number we are supposed to add up for 
	int target = atoi(av[1]);
	int set_size = ac - 2; //we minus two to leave the ./a.out and the target number followed after that 

	//if the set_size is less than 0 basically means, they have only passed one number and ./a.out 
	//another user input error 
	if (set_size <= 0)
		return 1;

	//we will now create two malloc to store the numbers 
	int *set = malloc (set_size * sizeof(int));
	int *subset = malloc (set_size * sizeof(int));

	if (!set || !subset)
	{
		free(set);
		free(subset);
		return 1;
	}

	int i = 0;
	int j = 2; //to leave the target 

	//we will fill all the numbers after target into the set first 
	while (j < ac)
	{
		set[i] = atoi (av[j]);
		i++;
		j++;
	}

	//the boolean value to says if the set has been found or not 
	int found = 0;

	//now, we will try to create subsets of the target through backtracking. 
	backtrack(set, subset, set_size, 0, 0, 0, target, &found);
	//the prototype of backtrack is as follows
	//backtrack(int *set, int *subset, int set_size, int subset_size, int index, int current_sum, int target, int *found)
	//if nothing is found, we will just display new line. 
	if (!found)
		printf("\n");

	//never forget to free the malloc 
	free(set);
	free(subset);
	return 0;
}
