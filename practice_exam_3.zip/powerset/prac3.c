#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void	print_subset(int *subset, int size)
{
	if (size == 0)
	{
		printf("\n");
		return;
	}

	int i =0;
	while (i < size)
	{
		if (i == size - 1)
		{
			printf("%d", subset[i]);
		}
		else
			printf("%d ", subset[i]);
		i++;
	}
	printf("\n");
}

int check_args(int ac, char **av)
{
	int i =1;
	while (i < ac)
	{
		int j = 0;
		if (av[i][j] == '-' || av[i][j] =='+')
			j++;
		while (av[i][j])
		{
			if (av[i][j] < '0' || av[i][j] > '9')
				return 0;
			j++;
		}
		i++;
	}
	return 1;
}

void backtrack(int *set, int *subset, int set_size, int subset_size, int index, int sum, int target, int *found)
{
	if (index == set_size)
	{
		if (sum == target)
		{
			print_subset(subset, subset_size);
			*found = 1;
		}
		return ;
	}

	backtrack(set, subset, set_size, subset_size, index + 1, sum, target, found);

	subset[subset_size] = set[index];
	backtrack(set, subset, set_size, subset_size + 1, index + 1, sum + set[index], target, found);
}

int main(int ac, char **av)
{
	if (ac < 2)
	{
		printf("\n");
		return 1;
	}
	if (!check_args(ac, av))
	{
		printf("\n");
		return 1;
	}

	int target = atoi(av[1]);
	int set_size = ac - 2;

	if (set_size <= 0)
	{
		return 1;
	}

	int *set;
	int *subset;

	set = malloc(set_size * sizeof(int));
	subset = malloc(set_size * sizeof (int));

	if (!set || !subset)
	{
		free(set);
		free(subset);
		return 1;
	}
	
	int i = 0;
	int j = 2;
	while (j < ac)
	{
		set[i] = atoi(av[j]);
		i++;
		j++;
	}
	int found = 0;

	backtrack(set, subset, set_size, 0, 0, 0, target, &found);
	if (!found)
	{
		printf("\n");
	}
	free(set);
	free(subset);
	return (0);
}
