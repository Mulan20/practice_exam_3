#define _GNU_SOURCE //for parameter memmem()
#ifndef BUFFER_SIZE
# define BUFFER_SIZE 42
#endif

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h> //for perro
#include <string.h> //for reaclloc

void ft_filter(char *buffer, const char *target)
{
	int i = 0; //index for buffer
	int target_len = strlen(target); //length of the target string
	int j;
       int k;

       while (buffer[i])
       {
       	j = 0;
	while (target[j] && buffer[i + j] == target[j])
		j++;

	if (j == target_len)
	{
		k = 0;
		while (k < target_len)
		{
			write(1, "*", 1);
			k++;
		}
		i += target_len;
	}
	else
	{
		write(1, &buffer[i], 1);
		i++;
	}

       }

}
int main(int argc, char **argv)
{
	//first we will need to check the argument count which should only be two. 
	if (argc != 2 || !argv[1] || argv[1][0] == '\0')
		return 1;

	char temp[BUFFER_SIZE]; //this is to read from stdin
	char *result = NULL; //this is a dynamite char array
	char *buffer; //this is for realloc function
	int total_read = 0; //this is to store the total number of bytes read
	ssize_t bytes; //this is to store the number of bytes read one time 
	
	//if we managed to read something from the stdin
	while ((bytes = read(0, temp, BUFFER_SIZE)) > 0)
	{
		//if we read smth, we will realloc the malloc with total_read+ bytes + 1
		buffer = realloc (result, total_read + bytes + 1);
		if (!buffer)
		{
			//if realloc failes
			free(result);
			perror("realloc");
			return 1;

		}
		result = buffer; //we will assign the reallocated buffer to result
		//we will move the unread data in temp to the front
		memmove(result + total_read, temp, bytes);
		//we will add bytes to the total read to update where we are
		total_read += bytes;
		result[total_read] = '\0';
	}

	//if we met error reading the stdin
	if (bytes < 0)
	{
		perror("read");
		free(result);
		return 1;
	}

	//if stdin was empty
	if (!result)
		return 0;

	ft_filter(result, argv[1]); //if we read smth, then we will filter now
	free(result);
	return 0;
}
