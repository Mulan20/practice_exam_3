rejunuron -> vitamin b12 supplement 
pregan => pain relieve for nerve 
pentoprazole sodium delay release tablet - gastric 
promat -> nausea, vomiting 
myomus -> pain relieve and paracetamol
