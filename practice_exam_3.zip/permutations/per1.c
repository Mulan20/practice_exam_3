#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int i = 0;
	while (str[i])
		i++;
	return i;
}

int	ft_isalpha(char c)
{
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
}

char	*ft_sort(char *str, int len)
{
	int i = 0;
	while (i < len)
	{
		if (str[i + 1] && str[i] > str[i + 1])
		{
			char temp = str[i];
			str[i] = str[i + 1];
			str[i + 1] = temp;
			i = 0;
		}
		else
			i++;
	}

	return str;
}

int	ft_strchr(char *str, char c)
{
	int i = 0;
	while (str[i])
	{
		if (str[i] == c)
			return 1;
		i++;
	}
	return 0;
}
void	permute(char *sorted, char *res, int pos)
{
	int i  = 0;
	int len = ft_strlen(sorted);

	if (pos == len)
	{
		write(1, res, len);
		write(1, "\n", 1);
		return ;
	}

	while (i < len)
	{
		if (!ft_strchr(res, sorted[i]))
		{
			res[pos] = sorted[i];
			permute(sorted, res, pos + 1);
			res[pos] = '\0';
		}
			i++;
	}
}

int main(int ac, char **av)
{
	//to check user input
	//to check alphabet
	//to sort
	//to backtrack for permutation
	//to free
	//
	if (ac != 2)
		return 1;

	int len = ft_strlen(av[1]);
	if (len <=0 || (av[1][0] == ' ' && !av[1][1] ))
		return 1;

	int i = 0;
	while (av[1][i])
	{
		if (!ft_isalpha(av[1][i]))
			return 1;
		i++;
	}

	char *sorted_str = ft_sort(av[1], len);

	char *res = calloc(len + 1, 1);
	if (!res)
		return 1;
	permute(sorted_str, res, 0);
	free(res);
	return 0;
}
