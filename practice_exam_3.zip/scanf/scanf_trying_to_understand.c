#include <stdio.h> //for stdin and input output functions
#include <stdarg.h> //for argument passed va_list, va_start
#include <ctype.h> //this is to check functions such as isspace, isdigit

//this function will return true if the space is found 
//there are controlled error situations in here
//first, we will try to check if the first word is end of file or there is an error with the stdin itself
int match_space(FILE *f)
{
	int ch = fgetc(f);
	if (ch == EOF && ferror(f))
		return -1;

	//then until ch is EOF, I will try to read f
	while (ch != EOF)
	{
		if (!isspace(ch))
		{
			ungetc(ch, f); //if it is space, I will return the space back to ch and break and return 1.
			break;
		}
		ch = fgetc(f); //if it is not space, another character is read
	}
	if (ferror(f)) //if there is a file error
		return -1;
	return 1;
}

//we will try to return 1 if the character is the same 
int match_char(FILE *f, char c)
{
	int ch = fgetc(f); //we will read from the file and check
	if (ch == c)
		return 1; //return true
	if (ch != EOF) //if not the same char, we will check whether is the end of the file
		ungetc(ch, f);

	return -1;
}

//this function will read the char from f to ap and return true on success
int scan_char(FILE *f, va_list ap)
{
	int ch = fgetc(f);
	char *cp = va_arg(ap, char *); //we will try to get the next char *f from ap and assigned to cp pointer
				       //so, cp is pointing one variable where the pointer is pointed
	if (ch == EOF)
		return -1;
	*cp = (char)ch; //we will assign the stdin to *cp
	return 1;
}
//this function will return 1 on the success of reading an int from f to ap
//this is a combination of atoi and scan_char
int scan_int(FILE *f, va_list ap)
{
	int sign = 1; //for positive or negative value
	int value = 0; //this is to manipulate the value everytime a new integer is read
	int ch = fgetc(f);//read one character 
	int *ip = va_arg(ap, int *); //initialize the pointer variable to passed to the pointed variable from ap
	int count =0; //this is for the total number of read integer 
//if the start is end of file, error return
	if (ch == EOF)
		return -1;
//if the character is space, we will skip that
	while (isspace(ch))
		ch = fgetc(f);
//if it is a negative number
	if (ch == '-')
	{
		sign = -1;
		ch = fgetc(f);
	}
	else if (ch == '+')
	{
		ch = fgetc(f);
	}
	if (!isdigit(ch)) //if it is not digit, return error 
	{
		ungetc(ch, f);
		return -1;
	}
	while (isdigit(ch)) //if it is digit atoi
	{
		value = value * 10 + (ch - '0');
		count++;
		ch = fgetc(f);
	}
	if (ch != EOF) //if it is not the end of file yet, we will push the character back to stdin
		ungetc(ch, f);
	if (count == 0) //if no integer is read, error
		return -1;
	*ip = value *sign; //assign to ap
	return 1; //success return
}
//this is like a menu for conversion based on the character we found in format
int match_conv(FILE *f, const char **format, va_list ap)
{
	//if c is found, we will just scan the char from stdin into ap
	//if d is found, we will try to skip the white spaces first and then scan it into ap
	//s for string
	switch(**format)
	{
		case 'c':
			return scan_char(f, ap);
		case 'd':
			match_space(f);
			return scan_int(f, ap);
		case 's':
			match_space(f);
			return scan_string(f, ap);
		case '\0':
			return -1;
		default:
			return -1;
	}
}

//core scanf logic in here
int	ft_vfscanf(FILE *f, const char *format, va_list ap)
{
	int nconv = 0; //this is to return the successfully converted number
	/*this is to check if the first word checked is the end of the file*/
	int c = fgetc(f);
	if (c == EOF)
		return EOF;

	//if it is not EOF, we will return it back to stdin and repeat the normal process
	ungetc(c, f);
	
	//while there is still string
	while (*format)
	{
		//if the conversion sign is found
		//we will get the character next to it
		//we will try to read it from f based on the character format in format into ap
		if (*format == '%')
		{
			format++;
			if (match_conv(f, &format, ap) != 1)
				break;
			//if it is read into ap successfully, we will increment the num of conversion
			nconv++;
		}
		else if (isspace(*format))
		{
			//if we find the space in the format, we will try to find the space in the f as well. if we cannot match the number of string, we will break the operation
			if (match_space(f) == -1)
				break;
		}
		else
		{
			//if it is just a normal character in both f and format, we will match it and skip 
			if (match_char(f, *format) != 1)
				break;
		}
		format++;
	}

	
	return nconv;
}
//this is the main scanf immitation
//this function will accept the string array we passed "%d %s" with 
//the variable we want to passed follow.
int	ft_scanf(const char *format, ...)
{
	//in this, we will try to initiate and assign the uncounted variables after the main string
	va_list ap; //this is how we try to initialize the variables being passed
	int ret; //this will store how many variables are being converted in the format

	va_start(ap, format); //we initialize the ap starting from format and the rest followed
	ret = ft_vfscanf(stdin, format, ap); //vfscanf will work like a scanf and returns the number of successful conversion
	va_end(ap); //we will end the variable

	return ret; //return the number.
}
