#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void	print_result(int *board, int n)
{
	int len;
	int i = 0;
	char str[12];
	while (i < n)
	{
	len = sprintf(str, "%d", board[i]);
	write(1, str, len);
	if (i < n - 1)
		write(1, " ", 1);
	i++;
	}
	write(1, "\n", 1);
}

int	is_safe(int *board, int col, int row)
{
	int i;

	i = 0;

	while (i < col)
	{
		if (board[i] == row || abs(board[i] - row) == abs(i - col))
			return (0);
		i++;
	}
	return (1);
}

void	backtrack(int* board, int col, int n)
{
	int row;
	if (col == n)
	{
		print_result(board, n);
		return;
	}
	row = 0;
	while (row < n)
	{
		if (is_safe(board, col, row))
		{
			board[col] = row;
			backtrack(board, col + 1, n);//you must pass n in the place of row because u are going to check all row
		}
		row++;
	}
}
int main(int ac, char **av)
{
	int n;
	int *board;

	if (ac != 2)
	{
		fprintf(stderr, "Wrong format: %s <n of queen>", av[0]);
		return 1;
	}

	n = atoi(av[1]);
	if (n <= 0)
	{
		fprintf(stderr, "The number of queen cannot be 0 or less than that!");
		return 1;
	}

	board = (int *)calloc(n, sizeof(int));
	if (!board)
	{
		fprintf(stderr, "failed allocation");
		return 1;
	}
	backtrack(board, 0, n);
	free(board);
	return (0);
}
