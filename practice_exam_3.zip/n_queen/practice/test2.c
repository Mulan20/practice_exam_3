#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void print_result(int *board, int n)
{
	char str[12];
	int len;
	int i = 0;
	while (i < n)
	{
		len = sprintf(str, "%d", board[i]);
		write(1, str, len);
		if (i < n -1 )
			write(1, " ", 1);
		i++;
	}
	write(1, "\n", 1);
}
int	safe(int *board, int col, int row)
{
	int i = 0;
	while (i < col)
	{
	if (board[i] == row || abs(board[i] - row) == abs(i - col))
			return 0;
	i++;
	}
	return 1;
}

void backtrack(int *board, int col, int n)
{
	int row;
	if (col == n)
	{
		print_result(board, n);
		return;
	}
	row = 0;
	while (row < n)
	{
		if (safe(board, col, row))
		{
			 board[col] = row;
			 backtrack(board, col + 1, n);
		}
		row++;
	}
}

int main(int ac, char **av)
{
	int n;
	int *board;

	if (ac != 2)
	{
		fprintf(stderr, "Usage: %s <n or queen>", av[0]);
		return 1;
	}

	n = atoi(av[1]);
	if (n <= 0)
		return 0;
	board = (int *)calloc(n, sizeof(int));
	if (!board)
	{
		fprintf(stderr, "Memory allocation failed");
		return 1;
	}
	backtrack(board, 0, n);
	free(board);
	return 0;
}
