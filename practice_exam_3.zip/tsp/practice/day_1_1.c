#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <float.h>
#include <math.h>

typedef struct {
	int x, y;
}	City;

float	cal_distance(City a, City b)
{
	float dx = a.x - b.x;
	float dy = a.y = b.y;
	return sqrtf((dx * dx) + (dy * dy));
}

float cal_total_distance(City *cities, int *path, int n)
{
	int i = 0;
	float total_distance= 0.00;

	while (i < n - 1)
	{
		total_distance += cal_distance(cities[path[i]], cities[path[i + 1]]);
		i++;
	}

	total_distance += cal_distance(cities[path[n - 1]], cities[path[0]]);

	return total_distance;
}

void swap (int *a, int *b)
{
	int swap = *a;
	*a = *b;
	*b = swap;
}

float	find_shortest_distance (City *cities, int *path,int n, int pos, float *min_distance)
{
	if (pos == n)
	{
		float current_distance = cal_total_distance(cities, path, n);
		if (current_distance < *min_distance)
			*min_distance = current_distance;
		return ; 
	}

	int i = 0;
	for (i = pos; i < n ; i++)
	{
		swap(&path[pos], &path[i]);
		find_shortest_distance(cities, path, n, pos + 1, min_distance);
		swap(&path[pos], &path[i]);
	}
}
int main(void)
{
	City cities[12];
	int n;

	while (n < 11 && (fscanf(stdin, "%f, %f", &cities[n].x, &citiies[n].y) == 2))
		n++:

	if (n < 2)
	{
		printf("0.00\n");
		return 0;
	}

	int path[12];
	for (int i =0; i < n ; i++)
		path[i] = i;

	float min_distance = FLT_MAX;

	find_shortest_distance(cities, path, n, 1, &min_distance);

	printf("%2f\n", min_distance);
	return 0;
}
