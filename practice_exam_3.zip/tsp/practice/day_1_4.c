#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

typedef struct{
	float x, y;
}	City;

float cal_dis(City a, City b)
{
	float dx = a.x - b.x;
	float dy = a.y - b.y;

	return sqrtf((dx * dx) + (dy * dy));
}

float cal_total_dis(City *cities, int *path, int n)
{
	float total = 0.0f;
	int i;

	for (i = 0; i < n - 1; i++)
	{
		total += cal_dis(cities[path[i]], cities[path[i + 1]]);
	}

	total += cal_dis(cities[path[n - 1]], cities[path[0]]);
	return total;
}

void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void find_shortest(City *cities, int *path, int n, int pos, float *min_dis)
{
	if (pos == n)
	{
		float current = cal_total_dis(cities, path, n);
		if (current < *min_dis)
			*min_dis = current;
		return;
	}

	for (int i = pos; i < n; i++)
	{
		swap(&path[pos], &path[i]);
		find_shortest(cities, path, n, pos + 1, min_dis);
		swap(&path[pos], &path[i]);
	}
}

int main(void)
{
	int n = 0;
	City cities[12];

	while (n < 11 && fscanf(stdin, "%f, %f", &cities[n].x, &cities[n].y) == 2)
		n++;

	if (n < 2)
	{
		printf("0.00\n");
		return 0;
	}

	int path[12];
	for (int i = 0; i < n; i++)
		path[i] = i;

	float min_dis = FLT_MAX;

	find_shortest(cities, path, n, 1, &min_dis);
	printf("%.2f\n", min_dis);
	return (0);
}
