#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int ft_strlen(char *s)
{
	int i =0;
	while (s[i])
		i++;
	return i;
}

int is_b(char *s)
{
	int i = 0;
	int balance = 0;
	while (s[i])
	{
		if (s[i] == '(')
			balance++;
		else if (s[i] == ')')
		{
			balance--;
			if (balance < 0)
				return 0;
		}
		i++;
	}
	return (balance == 0);
}

void ft_rip(char *s, int *min_rmv, int index, int current_rmv, int step)
{
	int i;
	char saved;

	if (current_rmv > *min_rmv)
		return ;

	if (is_b(s))
	{
		if (step == 1 && current_rmv < *min_rmv)
			*min_rmv = current_rmv;
		else if (step == 2 && current_rmv == *min_rmv)
		{
			write(1, s, ft_strlen(s));
			write(1, "\n", 1);
			return;
		}
	}

	i = 0;
	while (s[i])
	{
		if (s[i] == ')' || s[i] == '(')
		{
		saved = s[i];
		s[i] = ' ';
		ft_rip(s, min_rmv, index + 1, current_rmv + 1, step);
		s[i] = saved;
		}
		i++;
	}
}

int main(int ac, char **av)
{
	if (ac != 2 || av[1][0] == '\0')
		return 1;

	int i = 0;
	while (av[1][i])
	{
		if (av[1][i] != '(' && av[1][i] != ')')
			return 1;
		i++;
	}

	int min_rmv = ft_strlen(av[1]);
	ft_rip(av[1], &min_rmv, 0, 0, 1);

	ft_rip(av[1], &min_rmv, 0, 0, 2);

	return (0);
}
