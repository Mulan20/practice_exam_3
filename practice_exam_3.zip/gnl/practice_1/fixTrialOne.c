/*
 * EXERCISE: BROKEN_GNL (Get Next Line)
 * 
 * DESCRIPTION:
 * Implement get_next_line that reads line by line from a file descriptor.
 * This version may contain special cases or intentional "bugs".
*/

#include "get_next_line.h"

//this is to find the new line character
char *ft_strchr(char *s, int c)
{
	/*
  int i = 0;
  while(s[i] != c)
    i++;
  if (s[i] == c)
    return s + i;
  else
    return NULL;
    */
	int i = 0; //counter
		   //if the string is not being passed 
	if (!s)
		return NULL;
	//if the string is passed, we will find the new line character and return its pointer
	while (s[i])
	{
		if (s[i] == (char) c)
			return s + i;
		i++;
	}
	//if the string is passed and we cannot find the new line. 
	return NULL; 
}

//this is to copy the string 
void *ft_memcpy(void *dest, const void *src, size_t n)
{
	/*
  while(--n > 0)
    ((char *)dest)[n - 1] = ((char *)src)[n - 1];
  return dest;
  */
	size_t i = 0; //the pointer to return 
	while (i < n)
	{
		(char *(dest))[i] = (char *(src))[i];
		i++;
	}
	return dest;
}

//to find the size of string 
size_t ft_strlen(char *s)
{
	/*
  size_t res = 0;
  while (*s)
  {
    s++;
    res++;
  }
  return res;
  */
	size_t len = 0;
	if (!s)
		return len;
	while (s[len])
	{
		len++;
	}
	return len;
}

//to add s2 to s1
int str_append_mem(char **s1, char *s2, size_t size2)
{
	/*
  size_t size1 = ft_strlen(*s1);
  char *tmp = malloc(size2 + size1 + 1);
  if (!tmp)
    return 0;
  ft_memcpy(tmp, *s1, size1);
  ft_memcpy(tmp + size1, s2, size2);
  tmp[size1 + size2] = '\0';
  free(*s1);
  *s1 = tmp;
  return 1;
 */
       size_t size1 = 0;
	if (!*s1)
	 	size1 = 0;
	else
		size1 = ft_strlen(*s1);
	char	*temp;
	temp = malloc(size1 + size2 + 1);
	if (!temp)
		return 0;
	
	if (*s1)
		temp = ft_memcpy (temp, *s1, size1);
	temp = ft_memcpy(temp + size1, s2, size2);
	temp = [size1 + size2 + 1];
	free(*s1);
	*s1 = temp;
	return 1; 

}

int str_append_str(char **s1, char *s2)
{
	size_t size2 = ft_strlen(s2);
  return str_append_mem(s1, s2, size2);
}

void *ft_memmove(void *dest, const void *src, size_t n)
{
	/*
  if (dest > src)
    return ft_memmove(dest, src, n);
  else if (dest == src)
    return dest;
  size_t i = ft_strlen((char *)src) - 1;
  while (i >= 0)
  {
    ((char *)dest)[i] = ((char *)src)[i];
    i--;
  }
  return dest;
  */
	size_t i;
	if (! dest || src)
		return NULL;
	if (dest > src)
	{
		i = n;
		while (i > 0)
		{
			i--;
			(char *(dest))[i] = (char *(src))[i];
		}
	}
	else if (dest < src)
	{
		i = 0;
		while (i < n)
		{
			(char *(dest))[i] = (char *(src))[i];
			i++;
		}
	}
	return dest;
}

char *get_next_line(int fd)
{
	/*
  static char b[BUFFER_SIZE + 1] = "";
  char *ret = NULL;
  char *tmp = ft_strchr(b, '\n');
  while(!tmp)
  {
    if (!str_append_str(&ret, b))
      return (NULL);
    int read_ret = read(fd, b, BUFFER_SIZE);
    if (read_ret == -1)
      return (NULL);
    b[read_ret] = 0;
  }
  if (!str_append_mem(&ret, b, tmp - b + 1))
  {
    free(ret);
    return NULL;
  }
  return ret;
  */
	static char b[BUFFER_SIZE + 1] = "";
	char *ret = NULL;
	char *temp;
	int read_ret;

	while (1)
	{
		temp = ft_strchr(b, '\n');
		if (temp)
		{
			if (!str_append_mem(&ret, b, temp - b + 1))
				return (free(ret), NULL);
			ft_memmove(b, temp + 1, ft_strlen(temp + 1) + 1);
			return ret;
		}
		if (!str_append_str(&ret, b))
			return NULL;
		read_ret = read(fd, b, BUFFER_SIZE);
		if (read_ret <= 0)
		{
			b[0] ='\0';
			if (ret && *ret)
				return ret;
			free(ret);
			return NULL;
		}
		b[read_ret] = '\0';
	}
	return ret; 
}
